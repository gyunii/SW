public class Post {
    String category;
    String content;

    public Post(String category, String content) {
        this.category = category;
        this.content = content;
    }
}