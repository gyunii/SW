import java.util.*;

public class FITME {
    private static Scanner scanner = new Scanner(System.in);
    private static List<User> users = new ArrayList<>();
    private static List<Trainer> trainers = new ArrayList<>();

    public static void main(String[] args) {
        System.out.println("<<FITME 로그인>>");
        System.out.println("1. 사용자(User)로 로그인");
        System.out.println("2. 트레이너(Trainer)로 로그인");
        System.out.println("3. 관리자(Admin)로 로그인");
        System.out.print("로그인할 권한을 선택하세요 (1/2/3): ");
        int roleChoice = scanner.nextInt();
        scanner.nextLine();

        switch (roleChoice) {
            case 1: // 사용자(User)로 로그인
                userLogin();
                break;
            case 2: // 트레이너(Trainer)로 로그인
                handleTrainerFunctions();
                break;
            case 3: // 관리자(Admin)로 로그인
                handleAdminFunctions();
                break;
            default:
                System.out.println("잘못된 선택입니다.");
                break;
        }

        scanner.close();
    }

    // 사용자(User) 회원가입 메서드
    private static void userSignUp() {
        Registration registration = new Registration();
        User newUser = registration.signUp(scanner);
        users.add(newUser);
        System.out.println("회원 가입이 완료되었습니다.");

        handleUserFunctions(newUser);
    }

    // 사용자(User) 로그인 메서드
    private static void userLogin() {
        System.out.println("<<사용자 로그인>>");
        System.out.print("ID: ");
        String username = scanner.nextLine();
        System.out.print("PW: ");
        String password = scanner.nextLine();
        User user = authenticateUser(username, password);
        if (user != null) {
            System.out.println("로그인 성공!");
            handleUserFunctions(user);
        } else {
            System.out.println("사용자 로그인 실패! 회원 가입을 진행합니다.");
            userSignUp();
        }
    }

    // 사용자(User) 인증 메서드
    private static User authenticateUser(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    // 사용자(User) 기능 처리 메서드
    private static void handleUserFunctions(User user) {
        while (true) {
            System.out.println("==========================================================");
            System.out.println("<<사용자 기능 선택>>");
            System.out.println("1. 신체정보 입력하기");
            System.out.println("2. 식단 및 운동 기록하기");
            System.out.println("3. 커뮤니티 작성");
            System.out.println("4. 트레이너 피드백 확인");
            System.out.println("5. 로그아웃");
            System.out.print("기능을 선택하세요 (1/2/3/4/5): ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    recordBodyInfo(user);
                    break;
                case 2:
                    recordDietAndExercise(user.getRecord());
                    break;
                case 3:
                    writeCommunityPost();
                    break;
                case 4:
                    checkTrainerFeedback(user);
                    break;
                case 5:
                    System.out.println("로그아웃합니다.");
                    return;
                default:
                    System.out.println("잘못된 선택입니다. 다시 선택하세요.");
            }
        }
    }

    // 사용자 신체정보 입력 메서드
    private static void recordBodyInfo(User user) {
        System.out.println("<<신체정보 입력하기>>");
        System.out.print("체중(kg): ");
        double weight = scanner.nextDouble();
        System.out.print("신장(cm): ");
        double height = scanner.nextDouble();
        scanner.nextLine();

        user.initRecord(weight, height);

        Management management = new Management(scanner);
        management.addUser(user);

        System.out.println("신체정보 입력이 완료되었습니다.");
    }

    // 사용자 식단 및 운동 기록 메서드
    private static void recordDietAndExercise(Record record) {
        record.inputRecords();
    }

    // 커뮤니티 작성 메서드
    private static void writeCommunityPost() {
        Community community = new Community();

        while (true) {
            System.out.println("==========================================================");
            System.out.println("<<커뮤니티 작성하기>>");

            System.out.print("게시글 내용 입력: ");
            String postContent = scanner.nextLine().trim();

            System.out.println("카테고리 선택");
            System.out.println("1. 챌린지");
            System.out.println("2. 공지 및 이벤트");
            System.out.println("3. 다이어트 식단 및 운동 공유");
            System.out.print("번호를 입력하세요: ");
            int categoryChoice = scanner.nextInt();
            scanner.nextLine();

            String category;
            switch (categoryChoice) {
                case 1:
                    category = "챌린지";
                    break;
                case 2:
                    category = "공지 및 이벤트";
                    break;
                case 3:
                    category = "다이어트 식단 및 운동 공유";
                    break;
                default:
                    System.out.println("잘못된 번호입니다. 기본 카테고리로 설정합니다.");
                    category = "기본 카테고리";
            }

            Post post = new Post(category, postContent);
            community.addPost(post);

            System.out.println("\n커뮤니티 게시글을 작성하였습니다.");

            System.out.print("더 이상 게시글을 작성하시겠습니까? (Y/N): ");
            String choice = scanner.nextLine();
            if (!choice.equalsIgnoreCase("Y")) {
                break;
            }
        }
    }

    // 트레이너 피드백 확인 메서드
    private static void checkTrainerFeedback(User user) {
        user.printFeedbacks();
    }

    /*// 트레이너(Trainer) 로그인 메서드
    private static void trainerLogin() {
        System.out.println("<<트레이너 로그인>>");
        System.out.print("ID: ");
        String username = scanner.nextLine();
        System.out.print("PW: ");
        String password = scanner.nextLine();
        Trainer trainer = authenticateTrainer(username, password);
        if (trainer != null) {
            System.out.println("로그인 성공!");
            handleTrainerFunctions(trainer);
        } else {
            System.out.println("트레이너 로그인 실패!");
        }
    }*/

    // 트레이너(Trainer) 인증 메서드
    private static Trainer authenticateTrainer(String username, String password) {
        for (Trainer trainer : trainers) {
            if (trainer.getUsername().equals(username) && trainer.getPassword().equals(password)) {
                return trainer;
            }
        }
        return null;
    }

    // 트레이너(Trainer) 기능 처리 메서드
    private static void handleTrainerFunctions() {
        while (true) {
            System.out.println("==========================================================");
            System.out.println("<<트레이너 기능 선택>>");
            System.out.println("1. 등록된 회원 신체정보 열람");
            System.out.println("2. 회원에게 피드백 작성");
            System.out.println("3. 로그아웃");
            System.out.print("기능을 선택하세요 (1/2/3): ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    viewUserInfo();
                    break;
                case 2:
                    writeFeedback();
                    break;
                case 3:
                    System.out.println("로그아웃합니다.");
                    return;
                default:
                    System.out.println("잘못된 선택입니다. 다시 선택하세요.");
            }
        }
    }

    // 회원 신체정보 열람 메서드
    private static void viewUserInfo() {
        System.out.println("<<회원 신체정보 열람>>");
        for (User user : users) {
            user.getRecord().printTotalStatistics();
        }
    }

    // 회원에게 피드백 작성 메서드
    private static void writeFeedback() {
        System.out.println("<<회원에게 피드백 작성>>");
        System.out.print("피드백을 작성할 회원의 ID: ");
        String userId = scanner.nextLine();
        User user = findUserById(userId);
        if (user != null) {
            System.out.print("피드백 입력: ");
            String feedback = scanner.nextLine();
            user.addFeedback(feedback);
            System.out.println("피드백이 저장되었습니다.");
        } else {
            System.out.println("해당 ID의 회원을 찾을 수 없습니다.");
        }
    }

   /* // 관리자(Admin) 로그인 메서드
    private static void adminLogin() {
        System.out.println("<<관리자 로그인>>");
        System.out.print("ID: ");
        String username = scanner.nextLine();
        System.out.print("PW: ");
        String password = scanner.nextLine();
        Admin admin = authenticateAdmin(username, password);
        if (admin != null) {
            System.out.println("로그인 성공!");
            handleAdminFunctions(admin);
        } else {
            System.out.println("관리자 로그인 실패!");
        }
    }*/

    // 관리자(Admin) 인증 메서드
    private static Admin authenticateAdmin(String username, String password) {
        // 관리자 인증 로직 (임의로 간단히 구현)
        return null;
    }

    // 관리자(Admin) 기능 처리 메서드
    private static void handleAdminFunctions() {
        while (true) {
            System.out.println("==========================================================");
            System.out.println("<<관리자 기능 선택>>");
            System.out.println("1. 등록된 회원 신체정보 열람");
            System.out.println("2. 커뮤니티 작성");
            System.out.println("3. 로그아웃");
            System.out.print("기능을 선택하세요 (1/2/3): ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    viewUserInfo();
                    break;
                case 2:
                    writeCommunityPost();
                    break;
                case 3:
                    System.out.println("로그아웃합니다.");
                    return;
                default:
                    System.out.println("잘못된 선택입니다. 다시 선택하세요.");
            }
        }
    }

    // 회원 ID로 User 객체 찾기 메서드
    private static User findUserById(String userId) {
        for (User user : users) {
            if (user.getUsername().equals(userId)) {
                return user;
            }
        }
        return null;
    }
}
