import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Management {
    private List<User> userList;
    private List<Trainer> trainerList;
    private Scanner scanner;

    public Management() {
        this.userList = new ArrayList<>();
        this.trainerList = new ArrayList<>();
    }

    public Management(Scanner scanner) {
        this();
        this.scanner = scanner;
    }

    public void addUser(User user) {
        userList.add(user);
    }

    public User findUser(String username) {
        for (User user : userList) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    public void displayUserList() {
        for (User user : userList) {
            System.out.println("사용자명: " + user.getUsername() + ", 이메일: " + user.getEmail() + ", 키: " + user.getHeight() + ", 몸무게: " + user.getWeight());
        }
    }

    public void displayUserRecords() {
        System.out.println("회원의 신체 정보를 조회합니다.");
        System.out.print("사용자명을 입력하세요: ");
        String username = scanner.nextLine();

        for (User user : userList) {
            if (user.getUsername().equals(username)) {
                System.out.println(user.getUsername() + "님의 신체 정보:");
                user.record.printTotalStatistics();
                return;
            }
        }
        System.out.println("사용자를 찾을 수 없습니다.");
    }

    public void displayTrainerList() {
        System.out.println("트레이너 목록:");
        for (Trainer trainer : trainerList) {
            System.out.println("트레이너명: " + trainer.getName() + ", 이메일: " + trainer.getEmail());
        }
    }
}