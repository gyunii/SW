import java.util.*;

public class User {
    public String username;
    private String email;
    private double weight;
    private double height;
    String password;
    String phoneNumber;
    Record record;
    Community community;
    Trainer trainer;
    public List<String> feedbacks;

    public User(String username, String email, double weight, double height) {
        this.username = username;
        this.email = email;
        this.weight = weight;
        this.height = height;
    }

    public User(String username, String password, String phoneNumber, String email) {
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public Record getRecord() {
        return record;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public double getWeight() {
        return weight;
    }

    public double getHeight() {
        return height;
    }

    public void initRecord(double weight, double height) {
        this.record = new Record(weight, height);
    }

    public void addFeedback(String feedback) {
        this.feedbacks.add(feedback);
    }

    public void printFeedbacks() {
        if (feedbacks.isEmpty()) {
            System.out.println("피드백이 없습니다.");
        } else {
            System.out.println("피드백 목록:");
            for (String feedback : feedbacks) {
                System.out.println(feedback);
            }
        }

    }
}