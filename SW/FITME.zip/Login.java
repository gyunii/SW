public class Login {
    public boolean authenticate(String username, String password) {
        return true; // 임시로 항상 true 반환
    }
}