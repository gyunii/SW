import java.util.Scanner;

public class Admin {
    public void manage(User user) {
        Scanner scanner = new Scanner(System.in);

        Trainer trainer = new Trainer();
        System.out.println("트레이너 피드백을 제공합니다.");
        trainer.provideFeedback(user);

        Community community = new Community();
        System.out.println("\n커뮤니티에 새로운 게시글을 작성합니다.");
        System.out.print("게시글 내용을 입력하세요: ");
        String postContent = scanner.nextLine();
        System.out.print("게시글 카테고리를 입력하세요: ");
        String category = scanner.nextLine();
        Post post = new Post(category, postContent);
        community.addPost(post);

        System.out.println("\n신체 기록을 등록 또는 업데이트합니다.");
        System.out.print("체중(kg): ");
        double weight = scanner.nextDouble();
        System.out.print("신장(m): ");
        double height = scanner.nextDouble();
        if (user.record == null) {
            user.record = new Record(weight, height);
        } else {
            user.record.weight = weight;
            user.record.height = height;
        }

        System.out.println("\n사용자에게 메시지를 전송합니다.");
        System.out.println("관리자가 다양한 기능을 사용자에게 제공했습니다.");

        scanner.close();
    }
}