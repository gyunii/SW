import java.util.Scanner;

public class Record {
    public double weight;
    public double height;
    private String dietRecord;
    private String exerciseRecord;
    private Scanner scanner; // Scanner 객체를 인스턴스 변수로 사용

    public Record(double weight, double height) {
        this.weight = weight;
        this.height = height;
        this.dietRecord = "";
        this.exerciseRecord = "";
        this.scanner = new Scanner(System.in); // Scanner 객체 초기화
    }

    public void addDietRecord(String dietRecord) {
        this.dietRecord += dietRecord + "\n";
    }

    public void addExerciseRecord(String exerciseRecord) {
        this.exerciseRecord += exerciseRecord + "\n";
    }

    public void printRecords() {
        System.out.println("<<회원님의 기록>>");
        System.out.println("1. 음식 기록");
        System.out.println("2. 운동 기록");
        System.out.println("3. 총 통계 기록");
        System.out.print("번호를 입력하세요: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // 개행 문자 처리

        switch (choice) {
            case 1:
                System.out.println("<<음식 기록>>");
                System.out.println(this.dietRecord);
                break;
            case 2:
                System.out.println("<<운동 기록>>");
                System.out.println(this.exerciseRecord);
                break;
            case 3:
                System.out.println("<<총 통계 기록>>");
                printTotalStatistics(); // 총 통계 기록 출력
                break;
            default:
                System.out.println("잘못된 번호입니다.");
        }
    }

    public void printTotalStatistics() {
        double bmi = weight / (height * height);
        String obesity;
        if (bmi < 18.5) {
            obesity = "저체중";
        } else if (bmi < 23) {
            obesity = "정상";
        } else if (bmi < 25) {
            obesity = "과체중";
        } else if (bmi < 30) {
            obesity = "비만";
        } else {
            obesity = "고도 비만";
        }

        System.out.println("체중(kg): " + weight);
        System.out.println("신장(m): " + height);
        System.out.println("BMI 지수: " + bmi);
        System.out.println("비만도: " + obesity);
    }

    public void inputDietRecord() {
        System.out.println("식단 기록을 입력하세요. 입력을 마치려면 '완료'를 입력하세요.");
        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine();
            if (input.equals("완료")) {
                break;
            }
            addDietRecord(input);
        }
        System.out.println("식단 기록이 저장되었습니다.");
    }

    public void inputExerciseRecord() {
        System.out.println("운동 기록을 입력하세요. 입력을 마치려면 '완료'를 입력하세요.");
        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine();
            if (input.equals("완료")) {
                break;
            }
            addExerciseRecord(input);
        }
        System.out.println("운동 기록이 저장되었습니다.");
    }

    public void inputRecords() {
        inputDietRecord();
        inputExerciseRecord();
    }

    public void closeScanner() {
        scanner.close();
    }
}
