import java.util.Scanner;

public class Registration {
    public User register(String username, String password, String phoneNumber, String email) {
        return new User(username, password, phoneNumber, email);
    }

    public User signUp(Scanner scanner) {
        System.out.println("<<Sign Up>>");
        System.out.print("ID: ");
        String username = scanner.nextLine();
        System.out.print("PW: ");
        String password = scanner.nextLine();
        System.out.print("전화번호: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("이메일: ");
        String email = scanner.nextLine();
        return register(username, password, phoneNumber, email);
    }
}