import java.util.List;

public class Trainer {


    private String name;
    private String email;
    public String password;
    public String username;
    public String feedback;


    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public void provideFeedback(User user) {
        Record userRecord = user.record;

        if (userRecord != null) {
            double userWeight = userRecord.weight;
            double userHeight = userRecord.height;
            double bmi = userWeight / (userHeight * userHeight);

            String obesity;
            if (bmi < 18.5) {
                obesity = "저체중";
            } else if (bmi < 23) {
                obesity = "정상";
            } else if (bmi < 25) {
                obesity = "과체중";
            } else if (bmi < 30) {
                obesity = "비만";
            } else {
                obesity = "고도 비만";
            }

            // 기존 BMI 지수 및 비만도 출력
            System.out.println("BMI 지수: " + bmi);
            System.out.println("비만도: " + obesity);

            // 사용자 객체에 피드백 추가
            user.addFeedback(feedback);
        } else {
            System.out.println("사용자의 기록이 없습니다. 피드백을 제공할 수 없습니다.");
        }
    }
}